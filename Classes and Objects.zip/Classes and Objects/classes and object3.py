# update the value using  objects
class human:

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def methods(self):
        print("Hi, My name is "+ self.name)

h1 = human("Robert", 25)
h1.methods()

#del h1               # delete the object
h1.name = "Nirmal"
h1.age = 20
h1.methods()


