#Modes - read - r , write - w , create - x , append - a .
#open the file and read it
file = open("sample.txt", "r") #open("file name", "mode")

# please uncomment which part you have needed

#print(file.read()) #read() function will print the whole data from file

#print(file.read(3)) #read(number of character) will print the number of character.

#print(file.readline()) #readline() function will print the particular line from file
#print(file.readline()) #it will print the second line
#print(file.readline(3)) # it will print 3 characters from third line

#using for loop
for i in file:
    print(i)

file.close()

