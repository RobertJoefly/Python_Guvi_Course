import os

#please uncomment which part u have needed

#normal way to remove file
#os.remove("create.txt")      # To remove the file

# another way to remove file using if condition

if os.path.exists("create.txt"):
    os.remove("create.txt")
else:
    print("file doesn't exist")
