file = open("sample3.txt", "w") #w - write. it will overwrite the data in file.
                                # which means it will delete all data and replace the new data
file.write("Hi, This is robert")
file.close()

file = open("sample3.txt", "r")
print(file.read())
file.close()

