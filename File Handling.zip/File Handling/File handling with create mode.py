file = open("create.txt", "x") # x - create. it will create the new file.
                               # we can use w - write also to create a file
                               