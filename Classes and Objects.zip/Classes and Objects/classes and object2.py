#class and object using __init__ function and methods
class human:

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def methods(self):
        print("Hi, My name is "+ self.name)

h1 = human("Robert", 25)
h2 = human("Nirmal", 20)

h1.methods()
h2.methods()

