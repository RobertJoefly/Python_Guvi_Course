def is_prime(n):
    if n != 1:
        for i in range(2, n):
            if n % i == 0:
                print("Not Prime")
                break
        else:
            print("Prime")

user = int(input("Enter the number to find prime numbers it should be from 2 : "))
is_prime(user)