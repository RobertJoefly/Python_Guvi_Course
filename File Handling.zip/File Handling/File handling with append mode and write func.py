file = open("sample1.txt", "a") #a=appenf. it will add the new data at the end of the file
file.write(" New line")
file.close()

file = open("sample1.txt", "r")
print(file.read())
file.close()