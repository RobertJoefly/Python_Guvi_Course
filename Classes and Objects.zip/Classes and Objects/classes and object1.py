#class and object using __init__ function
class human:

    def __init__(self, name, age):
        self.name = name
        self.age = age

h1 = human("Robert", 25)
print(h1.name)
print(h1.age)