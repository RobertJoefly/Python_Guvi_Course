#classes and objects

class human:    #human - class name
    x=13        #property = property value

h = human()     # object = class
print(h.x)      #print(object.class property)